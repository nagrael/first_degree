#!/bin/sh

java -jar Jan_gorski.jar
